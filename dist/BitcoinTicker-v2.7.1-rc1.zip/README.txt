Bitcoin Ticker (+Widget) v2.7.1-rc1

Release candidate change:
- Manual widget refresh requests now use Android's expedited WorkManager path.
- If expedited quota is unavailable, Android falls back to normal scheduled work.
- The widget displays its refreshing state immediately after a manual tap.
- Periodic background refresh remains battery-conscious and uses WorkManager.

Production package: dev.steamy.bitcointicker
Version code: 44

Install file:
BitcoinTicker-v2.7.1-rc1.apk
